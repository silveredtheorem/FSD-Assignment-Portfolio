import ProjectCard from "../components/ProjectCard";
import projects from "../data/projects";
import "../components/ProjectCard.css";

export default function Projects() {
  return (
    <section className="section" aria-labelledby="projects-heading">
      <div className="container">
        <h2 id="projects-heading" className="section__heading">
          projects
        </h2>
        <p className="section__subheading">
          a mix of shipped side projects and one research internship. click into any card for the full write-up.
        </p>
        <div className="projects__grid">
          {projects.map((project) => (
            <ProjectCard key={project.id} {...project} />
          ))}
        </div>
      </div>
    </section>
  );
}
